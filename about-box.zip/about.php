<?php 
session_start();

?>
<?php
 
include("./compoment/function/function.php");
$get = get_element_partenair($dattabase);
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>About </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.ico">
    
    <!-- CSS 
    ========================= -->
   
    <!-- Bootstrap CSS -->
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

    <link rel="stylesheet" href="cont/css/style.css">
    <link rel="stylesheet" href="cont/css/plugins.css">
    <link rel="stylesheet" href="cont/css/bootstrap.min.css">
    <link rel="stylesheet" href="cont/css/Pe-icon-7-stroke.css">
    <link rel="stylesheet" href="cont/css/icofont.min.css">
    <link rel="stylesheet" href="cont/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="cont/slick/slick-theme.css"/>
</head>

<body>

<!-- Main Wrapper Start -->
<div class="main-wrapper">
   
    <!-- header-area start -->
    <div class="header-area">
        <!-- header-top start -->
        <?php
          include("compoment/header.php");
         ?>
        <!-- header-bottom-area End -->      
    </div>
    <!-- header-area end -->
    
    <!-- breadcrumb-area start -->
    <div class="breadcrumb-area section-ptb">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h2 class="breadcrumb-title">About</h2>
                    <!-- breadcrumb-list start -->
                    <ul class="breadcrumb-list">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active">About</li>
                    </ul>
                    <!-- breadcrumb-list end -->
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumb-area end -->
    
    <!-- Repair-make-area Start -->
      <!-- Start About Area -->
    <div class="about-area section-pt mt--30" style="background-color:#eefff4" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="agency-benefits">
                        <div class="content text-right">
                            <h2><span> ... رسالتنا</span> </h2>
                            <p>
                            المركز اختصارا TDC-Training and Development Center  مؤسسة محلية تهتم بالتنمية المستدامة وبالاخص التكوين 
و التدريب لمختلف فآت المجتمع من اجل الحصول على شهادة معتمدة في مجالات حيوية و وفق حاجيات المجتمع ومتطلبات سوق الشغل.
المركز هو وسيلة علمية و تقنية نسعى من خلالها تقديم حلول عملية لعدة مشاكل و متطلبات اجتماعية واقتصادية و حضارية.
استراتيجيتنا ترتكز على ثلاثة محاوررئيسية:

                            </p>
                            <h3 class ="text-right"> : المحور الأول  </h3>
                            <p>
                            الاعتماد على العنصر البشري المؤهل و المدرب و المثقف و توجيهه نحو تحقيق الأهداف بأفضل الطرق العلمية و بالأخص وسط الطبقة الشبابية المتخرجة من مختلف المؤسسات التعليمة و التربوية و التكوينية.
</p>
<h3 class ="text-right"> : 
المحور الثاني  </h3>
                            <p>
                            اعتماد المؤسسة الاقتصادية و بالاخص المؤسسة الصغيرة و المتوسطة كوحدة أساسية للانطلاق نحو اقتصاد متين و قوي.
                        </p>
<h3 class ="text-right"> : المحور الثالث </h3>
                            <p>
                            الاعتماد على المنهجية العلمية و البحث العلمي و التطوير في عملية بناء المؤسسة الاقتصادية ومن ثم تحقيق التنمية المستدامة.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="agency-thumb">
                        <div class="thumb">
                            <img src="image/logo/logo.jpg" alt="Agency Images">
                            <div class="play-btn">
                                <a class="video-popup" href="https://www.youtube.com/watch?v=gNe5zj7ZCy4"><i class="fa fa-play" style="color: black;"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About Area -->
    <!-- Repair-make-area End -->
    
    <!-- Project-count-inner Start -->
    <div class="project-count-inner bg-grey section-pb section-pt-80 mt--30">
        <div class="container">
            <div class="row">
            <div class="col-lg-3 col-sm-6">
                <!-- counter start -->
                <div class="counter text-center">
                    <h3 class="counter-active">112</h3>
                    <p>Award Won</p>
                </div>
                <!-- counter end -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <!-- counter start -->
                <div class="counter text-center">
                    <h3 class="counter-active">345</h3>
                    <p>Project Done</p>
                </div>
                <!-- counter end -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <!-- counter start --> 
                <div class="counter text-center">
                    <h3 class="counter-active">215</h3>
                    <p>Satisfied Client</p>
                </div>
                <!-- counter end -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <!-- counter start -->
                <div class="counter text-center">
                    <h3 class="counter-active">124</h3>
                    <p>Running Project</p>
                </div>
                <!-- counter start -->
            </div>
        </div>
        </div>
    </div>
    <!-- Project-count-inner End -->
    
    <!-- FAQ area Start -->

    <!-- FAQ area End -->
    
    <div class="team-area  section-ptb">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-center">
                         <h4>OUR partener</h4>
                         
                    </div>
                </div>
            </div>
            <div class="row slick-partner-area ">
                  <?php 
                   foreach($get as $key)
                   {

           
                  ?>
                <div class="col-lg-4 col-md-6">
                    <!-- single-member Start -->
                    <div class="single-team-member mt--30">
                        <div class="team-member-image hover-2">
                            <img src="image/partner/<?php echo $key['link'] ?>" alt="">
                            <div class="team-social-link">
                                <ul>
                                    <li><a href="#"><i class="icofont-facebook"></i></a></li>
                                    <li><a href="#"><i class="icofont-twitter"></i></a></li>
                                    <li><a href="#"><i class="icofont-pinterest"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                    <!-- single-member End -->
                </div>
                 <?php 
                 }
                 ?>
            </div>
        </div>
    </div>
    

   
    
<?php 
   include("compoment/footer_jslink.php")
?>
</div>




</body>

</html>